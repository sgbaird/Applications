(* ::Package:: *)

(* ::Input::Initialization:: *)
BeginPackage["QuantumNumbers`"];
QuantumNumbers::usage="Get quantum numbers {n,l,\!\(\*SubscriptBox[\(m\), \(l\)]\),\!\(\*SubscriptBox[\(m\), \(s\)]\)} for outermost valence electron of element (e.g. \"O\" or 8)

Example usage:
QuantumNumbers[\"O\"]
QuantumNumbers[8]";

Begin["Private`"];
QuantumNumbers[elem_]:=Module[{n,l,mlPossible,mlTot,nfilled,ml,ms},
n[elem]:=ElementData[elem,"Period"];
l[elem]:=ElementData[elem,"Block"]/.{"s"->0,"p"->1,"d"->2,"f"->3};
mlPossible[elem]:=Range[-l[elem],l[elem]];
mlTot[elem]:=Length[mlPossible[elem]];
nfilled[elem]:=ElementData[elem,"ElectronConfiguration"][[-1,-1]];
ml[elem]:=Extract[Flatten[ConstantArray[mlPossible[elem],2]],2mlTot[elem]-nfilled[elem]+1];(*convention that it fills from left (-l) to right (+l)*)
ms[elem]:=If[nfilled[elem]<=mlTot[elem],1/2,-(1/2)] ;(*Apply Hund's rule, convention that spin-up fills orbitals first, i.e. last to be filled (-1/2) is first to be taken*)
{n[elem],l[elem],ml[elem],ms[elem]}];
End[]
EndPackage[]


(* ::Text:: *)
(*Code Graveyard*)


(* ::Input:: *)
(*(*n[elem_]:=ElementData[elem,"Period"]*)
(*l[elem_]:=ElementData[elem,"Block"]/.{"s"\[Rule]0,"p"\[Rule]1,"d"\[Rule]2,"f"\[Rule]3}*)
(*(*Subscript[m, l][elem_]:=Range[-l[elem],l[elem]]*)*)
(*Subscript[m, l,possible][elem_]:=Range[-l[elem],l[elem]];*)
(*Subscript[m, l,tot][elem_]:=Length[Subscript[m, l,possible][elem]]*)
(*(*Valence[elem_]:=ElementData[elem,"Valence"];*)*)
(*Subscript[n, filled][elem_]:=ElementData[elem,"ElectronConfiguration"]\[LeftDoubleBracket]-1,-1\[RightDoubleBracket]*)
(*Subscript[m, l][elem_]:=Extract[Flatten[ConstantArray[Subscript[m, l,possible][elem],2]],2Subscript[m, l,tot][elem]-Subscript[n, filled][elem]+1];(*convention that it fills from left (-l) to right (+l)*)*)
(*Subscript[s, l][elem_]:=If[Subscript[n, filled][elem]\[LessEqual]Subscript[m, l,tot][elem],1/2,-(1/2)] (*Apply Hund's rule, convention that spin-up fills orbitals first, i.e. last to be filled (-1/2) is first to be taken*)*)
(*QuantumNumbers[elem_]:={n[elem],l[elem],Subscript[m, l][elem],Subscript[s, l][elem]}*)*)
